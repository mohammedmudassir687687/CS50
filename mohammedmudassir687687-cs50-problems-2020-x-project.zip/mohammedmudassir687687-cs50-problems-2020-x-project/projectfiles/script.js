document.querySelector('#button-addon2').onclick = function(){
    let x = document.querySelector('#name').value;

if(x === "")
{
    alert("Fill the empty field.");
    document.querySelector('#showname').innerHTML = "Hey Potterhead!";
}
else
{
    alert("Submitted!");
    document.querySelector('#showname').innerHTML = "Hello " + x + "!";
}
};



